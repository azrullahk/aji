let count = 0

setInterval(() => {
    count ++

    if (count%2!=0) {
        console.log("peransssss")
    } 
    else if (count%10==0) {
        console.log("andreasss eka adii")
    }
    else {
        console.log(count)
    }
}, 1000)